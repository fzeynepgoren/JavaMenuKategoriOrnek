import java.util.ArrayList;
import java.util.List;


public interface MenuElemani

{
    public void goster(String girinti);

}
