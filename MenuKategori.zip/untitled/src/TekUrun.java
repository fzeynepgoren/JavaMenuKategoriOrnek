/*public class TekUrun implements MenuElemani

{
    String ad;
    public double fiyat;

    @Override
    public void goster(String girinti) {

    }
}
*/


public class TekUrun implements MenuElemani {
    String ad;
    int fiyat;

    public TekUrun(String ad, int fiyat) {
        this.ad = ad;
        this.fiyat = fiyat;
    }

    @Override
    public void goster(String girinti) {
        System.out.println(girinti + "Ürün: " + ad + " Fiyat: " + fiyat + " TL");
    }
}