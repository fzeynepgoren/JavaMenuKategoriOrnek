/*
import java.util.ArrayList;
import java.util.List;

public class MenuKategori implements MenuElemani
{
    String ad;
    List<MenuElemani>elemanlar;

    public MenuElemani String(ad) {
         this.ad=ad;
    }

    public void ekle(MenuElemani eleman){

    }


    public void sil(MenuElemani eleman)
    {

    }

    public  void goster(String girinti)
    {
        System.out.println(girinti +" kategori: "+ ad );
        for (MenuElemani eleman:elemanlar)
        {
            eleman.goster(girinti+ " ");
        }
    }
}
*/

import java.util.ArrayList;
import java.util.List;


public class MenuKategori implements MenuElemani {
    String ad;
    List<MenuElemani> elemanlar;

    public MenuKategori(String ad) {
        this.ad = ad;
        this.elemanlar = new ArrayList<>();
    }

    public void ekle(MenuElemani eleman) {
        elemanlar.add(eleman);
    }

    public void sil(MenuElemani eleman) {
        elemanlar.remove(eleman);
    }

    public void goster(String girinti) {
        System.out.println(girinti + "Kategori: " + ad);
        for (MenuElemani eleman : elemanlar) {
            eleman.goster(girinti + "  ");
        }
    }
}


