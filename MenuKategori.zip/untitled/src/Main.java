public class Main {
    public static void main(String[] args)
    {
        TekUrun Durum = new TekUrun("Dürüm",150);
        TekUrun Ayran = new TekUrun("Ayran",70);


        MenuKategori mk= new MenuKategori("Ana Menu");
        MenuKategori mkIcecek= new MenuKategori("İçecek ");
        MenuKategori mkYiyecek=new MenuKategori("Yiyecek");


        mkIcecek.ekle(Ayran);
        mkYiyecek.ekle(Durum);

        mk.ekle(mkIcecek);
        mk.ekle(mkYiyecek);
        mk.ekle(Durum);

        mk.goster(" - ");




    }

}


